#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--manifest", default="MANIFEST.json")
args = parser.parse_args()
manifest_path = Path(args.manifest)
manifest = json.loads(manifest_path.read_text())
root = manifest_path.parent
bad = []
for row in manifest["members"]:
    path = root / row["package_relative_path"]
    actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    expected = row["current_sha256"]
    if actual != expected:
        bad.append({"path": row["package_relative_path"], "expected": expected, "actual": actual})
    if row["match"] is True and actual != row["expected_frozen_sha256"]:
        bad.append({"path": row["package_relative_path"], "expected_frozen": row["expected_frozen_sha256"], "actual": actual})
print(json.dumps({"status": "PASS" if not bad else "FAIL", "checked": len(manifest["members"]), "bad": bad}, indent=2))
raise SystemExit(1 if bad else 0)
