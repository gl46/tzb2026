# 第八轮｜按 v6 终审七项条件逐条闭合,请求短复审

**本轮不请求你重读全部材料。**你上轮把签字条件收敛成七项,且明确说"无需新实验,也无需改变路线"。本文逐条对账,只请你复核这七项。

**上轮你的判决**:字节完整性通过,**主张语义完整性未通过**。我们接受这个区分,它比"通过/不通过"准确——问题确实全部落在 claim 与 evidence 的**语义范围**上,而不在字节。

**先说最重要的一句**:你上轮拒绝在 v4 摘要上签字,直接导致我们取回主件;取回当天就查出 BLIND secondary metric 的单例差异。本轮 P0-2 又是同一机制——**你数了 `bound_in` 里的条目,发现量词覆盖三个 split 而证据只有两个**。这两次都不是措辞洁癖,是真的抓出了错。

---

## 七项条件逐条对账

### 1｜所有"逐例完全一致"补 `expectation_match` 限定 —— 已闭合

权威清单主事实区原已限定;本轮补了你点名的四处下游:

| 位置 | 处置 |
|---|---|
| `deck-p1-p3-p4-p6-content-blocks.md:152–153` | 加指标限定 + 同页脚注(S5 执行) |
| `appendix-qwen-lane-defense-qa.md:86` | 加 `expectation_match` 限定(S5 执行) |
| `appendix-qwen-lane-defense-qa.md:146` | 改为"在 `expectation_match` 上逐族一致;MANUAL_BLIND secondary structural metrics 有 1 例差异"(S5 执行) |
| `CLAIMS-SHEET:5b` 小节标题 | **标题内直接加限定**,并加一行"标题即限定,不得省;不能指望读者往前翻" |

### 2｜同屏披露 BLIND 一例 secondary metric 差异 —— 已闭合

允许表述按你给的定性写死:

> MANUAL_BLIND 有一例输出行为发生变化:BASE 产生契约错误,LoRA 产生结构合法但目标错误的计划;**任务正确性没有改善**。

禁用清单已写入权威清单:结构合规性收益 / 鲁棒性提升 / 安全性提升 / **一例纠正** / `+1/45` 能力增益。定性统一为**行为差异诊断,不是收益**。

### 3｜DEV/TEST/BLIND 三 split 身份绑定 —— **走选择 A(补件),不是降级**

你给了两条路。我们查证后走 A,因为证据确实存在,只是上一轮没取:

- `icl-dev-trained-report-v3.json`(DEV candidate 臂)**确实带** `adapter_tree_sha256 = 8a09f56a…`;
- 它由包内 `icl-dev-paired-supporting-report-v3.json` 的 `candidate_report_sha256` **逐字节钉住**;
- 同时取回 DEV baseline 臂(由 `baseline_report_sha256` 钉住),**adapter 字段为 `null`**,与 TEST/BLIND 两臂结构对称。

现在三个 split 全部成立:

```
TEST  candidate  adapter = 8a09f56a      TEST  baseline  adapter = null
BLIND candidate  adapter = 8a09f56a      BLIND baseline  adapter = null
DEV   candidate  adapter = 8a09f56a      DEV   baseline  adapter = null
```

**这是第二次只读取件**,同一主机、同一目录、同一用户授权,**在收据里显式声明为对原枚举清单的两文件扩展**,不静默并入。取件保真现为 **15/15**(原 13/13)。

### 4｜`S5_ADAPTER_LOADED_TREE_IDENTITY` 重命名 —— 已闭合

改为 **`S5_RECORDED_ADAPTER_TREE_IDENTITY`**,旧 id 记为 supersedes。

你这条抓得最准,我们内部把它归到同一病型:**谓词贴错了主语**。一个 claim 不能同时叫 `LOADED`、描述成 `exact loaded identity`、又在 unsupported scope 里承认没有 runtime 证明。**这三者中必须有一个是假的,而假的那个是名字。**

允许:发布回执与三份 candidate 报告**记录了**同一 tree digest。
禁止:运行时加载已证明 / bit-exact / exact loaded identity 已建立。

### 5｜safetensors 与 tree 可验证措辞降级 —— 已闭合

作废表述:"树身份仍可凭发布回执复核" / "tree identity remains verifiable without shipping the payload"。

改为你给的二分:

**包内可核**:发布回执与三份 candidate 报告**记录了同一 tree digest**,这一记录的一致性可核对。
**包内不可核**(payload 不在包内):独立重算 safetensors 摘要、独立重建完整 adapter tree、证明回执所记 payload digest 对应真实 payload、证明运行时加载了该权重。

收据里保留了一条 `superseded_overclaim` 字段,写明旧句为什么太强——**不删,留作记录**。

### 6｜权威清单里的包内路径错误 —— 已闭合

`reports/evidence-s5-node2-20260831/FETCH-RECEIPT.json` 是**工作树路径**,发行包内实际是 `evidence/s5/node2-original/FETCH-RECEIPT.json`。已改为引用包内路径并注明两者关系。

这条是我们自己的低级错误:**权威清单给出的证据入口在发行包里解析不了**。

### 7｜统一"执行前验证链" + 重建 —— 已闭合

整条链统一称**执行前验证链**(类型化运行时契约层 + 语义验证器)。"语义执行门/语义门"**只能**用于确实到达 semantic validator 的 23 例,不得覆盖全部 24 例。

已改:权威清单 §6 标题与命名裁定、第 7/8 页、视频脚本(开场角标、能力矩阵、结尾旁白三处)。S5 负责 `deck-p2-p5`、`deck-p1-p3-p4-p6`、两份附录。MANIFEST / 索引重建与 archive SHA、exact-match 重跑随新包一并执行。

---

---

## 第八项:你没提,我们自己查出来的

七项之外我们自查出一处,**在你发现之前主动交出来**,因为它是我们主动写进 deck 的数字,而且**评委可以自己复现**。

**`135` 是七文件 scoped 子集,不是仓库全量测试。**

证据件 `/commands/pytest` 的原文是 "Exact historical **seven-file** terminal P1 compatibility pytest command",135 passed in 3.59s。而我们在第 8 页写的是:

> 当前冻结实现下 `135` 项回归测试通过

**"当前冻结实现下"是时间范围,不是文件范围。** 读者会读成"回归套件通过"。

同日我们用项目 `.venv`(Python 3.13.12)实测**全仓**:

```
14 failed, 1933 passed, 5 skipped in 225.51s
另有 tests/unit/test_m2c_s3_dataset.py collection error(缺 artifacts/m2b/dataset-v2.jsonl)
裸 pytest -q 会直接中止
```

14 个失败全部是 `test_m2c_*`(M2C 治理 lane:qb_adr_gate 2、qwen_adr0026 2、s3_collection_plan 3、s3_public_category 1、s4_entry_gate 3、status 3),**没有一个属于 `qwen_brain`**——也就是说不在本次交付的安全层里。但我们**没有逐个诊断成因**,所以**不说"都是无害的"**。(其中至少一个是时间依赖的:`D1_S2_DEADLINE_UNMEASURED` vs `S2_IN_PROGRESS_UNMEASURED`,过了 deadline 才变。但这只是一个观察,不是对全部 14 个的结论。)

**已改**:权威清单 §6 加 v5 范围更正,第 8 页改为"在冻结语义契约路径的七文件回归子集上,135 项全部通过",并禁止裸写。

**这一项最值得你评的地方,是它的来源**:证据件自身的 `proof_boundary` 只写了 "not evidence of the original P1 run",**完全没有声明文件范围,也没提全仓有失败**。所以这不是 deck 抄错了证据——**是证据件对自己的范围说少了,而下游忠实地继承了这个欠声明。**

这正是你上轮那个模式的一个新变种:前面几条是"人给证据贴错了谓词",这一条是"**证据自己没说清自己的边界**"。请判:`supported_scope` / `unsupported_scope` 这套字段,能不能靠 lint 强制要求"测试类证据必须声明选择器范围与全量对照"?还是这仍然落在你说的第三层人工门里?

---

## 我们采纳的其余判断(不需要你再答)

**LoRA 天花板**:接受你的定性。"未检出退化"**已作废**——它听起来像统计检验结论。现行对外短句:

> **主指标未观察到变化;不证明非退化。**

完整版按你给的写法保留 cluster=2/3、`UNSTABLE_LOW_CLUSTER_COUNT`、无 non-inferiority design、无裸基座回归四项限定。

**第 3 页分工**:接受。结构见证归 typed/runtime contract;semantic validator 的见证从已有 23 例里另选一个真正的 target/world/automaton 语义错误,不新增实验。

**"准确标注 ≠ 自我否定"**:接受降为**内部编辑原则**,不作对外口号,并改写为你给的可执行形式——先完整报正面事实,再紧邻标测试介质、拒绝组件与 unsupported scope。

**元层三层防线**:句法类型门与关系完整性门我们认为可以做成一次性 presubmit lint,**但排在 9/3 代码冻结之后**;冻结前只采纳其行为部分。第三层的两个固定提问("这份工件最强能支持什么""存在什么替代世界使同样工件出现而结论不成立")已写入内部复核清单。

---

## 本轮请你回答

1. 七项是否**逐项**闭合;哪一项你认为仍未闭合。
2. 选择 A 的补件是否真的满足 `ACROSS_SPLITS` 的量词——特别是:**DEV baseline 臂用 `report-two-base-v2.json`** 是否构成正确的对照臂(它由 DEV paired 报告的 `baseline_report_sha256` 钉住,但文件名与另外两个 split 的命名不同构)。
3. 是否可以签"在这一集合上,限定范围通过"。若仍不能,请只列**阻断项**,不要再给非阻断建议——距代码冻结 9/3 只剩三天,我们需要把改动面收敛。

**一个我们自己没解决的问题,顺便请你判**:本轮七项里有五项是"名字大于证据"。我们已经在权威清单里加了证据类型→允许推导表和三条可机器化 lint,但 P0-3 那种错误(`LOADED` vs `RECORDED`)**能被 lint 抓到吗**?我们的判断是能——只要 `evidence_type = REPORT_RECORDED_TREE_DIGEST` 禁止 claim 名含 `LOADED`。但这依赖有人先正确填 `evidence_type`,而填错 `evidence_type` 本身又是同一类错误。**这个递归有底吗?**
