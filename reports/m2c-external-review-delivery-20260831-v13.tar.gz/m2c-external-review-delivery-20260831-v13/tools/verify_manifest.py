#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
parser = argparse.ArgumentParser()
parser.add_argument("--manifest", default="MANIFEST.json")
args = parser.parse_args()
manifest_path = Path(args.manifest)
manifest = json.loads(manifest_path.read_text())
root = manifest_path.parent.resolve()
bad = []
seen = set()
for row in manifest["members"]:
    rel = row["package_relative_path"]
    pure = PurePosixPath(rel)
    if pure.is_absolute() or ".." in pure.parts or rel != pure.as_posix() or rel in seen:
        bad.append({"path": rel, "error": "unsafe_or_duplicate_manifest_path"})
        continue
    seen.add(rel)
    path = root / rel
    actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    if actual != row["current_sha256"]:
        bad.append({"path": rel, "expected_current": row["current_sha256"], "actual": actual})
    if row["match"] is True and actual != row["expected_reference_sha256"]:
        bad.append({"path": rel, "expected_reference": row["expected_reference_sha256"], "actual": actual})
    frozen = row["expected_frozen_sha256"]
    if row["match"] is True and frozen != "NOT_APPLICABLE" and actual != frozen:
        bad.append({"path": rel, "expected_frozen": frozen, "actual": actual})
actual_files = sorted(path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file() and path != manifest_path.resolve())
manifest_files = sorted(seen)
if actual_files != manifest_files:
    bad.append({"error": "manifest_inventory_mismatch", "unlisted_files": sorted(set(actual_files)-set(manifest_files)), "missing_files": sorted(set(manifest_files)-set(actual_files))})
if len(manifest["members"]) != manifest["member_count_excluding_manifest"]:
    bad.append({"error": "member_count_mismatch"})
print(json.dumps({"status": "PASS" if not bad else "FAIL", "checked": len(manifest["members"]), "actual_file_count_excluding_manifest": len(actual_files), "bad": bad}, ensure_ascii=False, indent=2))
raise SystemExit(1 if bad else 0)
