#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

MIRRORS = {
    "claims_sheet": (
        "reports/CLAIMS-SHEET-20260831.md",
        "```text\n{value}\n```",
    ),
    "deck_campaign": (
        "reports/deck-m2c-campaign-block-20260831.md",
        "```text\n{value}\n```",
    ),
    "video_subtitle": (
        "reports/deck-video-script-20260831.md",
        "> `{value}`",
    ),
}

parser = argparse.ArgumentParser()
parser.add_argument("--root", default=".")
parser.add_argument(
    "--halted-report",
    default="evidence/campaign/m2c-r13239-r3-honest-halted-campaign-report-v2.json",
)
parser.add_argument("--receipt")
args = parser.parse_args()
root = Path(args.root)
report_path = root / args.halted_report
report = json.loads(report_path.read_text())
value = report["aggregate_accounting"]["aggregate_conclusion"]
checks = []
for name, (relative, template) in MIRRORS.items():
    path = root / relative
    text = path.read_text()
    expected = template.format(value=value)
    count = text.count(expected)
    checks.append(
        {
            "name": name,
            "path": relative,
            "expected_fragment_utf8_hex": expected.encode("utf-8").hex(),
            "occurrence_count": count,
            "match": count == 1,
        }
    )
receipt = {
    "schema_version": "M2CCampaignConclusionExactMatchReceiptV1",
    "status": "PASS" if all(row["match"] for row in checks) else "FAIL",
    "source": {
        "path": args.halted_report,
        "json_pointer": "/aggregate_accounting/aggregate_conclusion",
        "value_utf8_hex": value.encode("utf-8").hex(),
        "line_ends_with_full_stop": value.endswith("。"),
    },
    "checks": checks,
}
rendered = json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
if args.receipt:
    destination = root / args.receipt
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o444)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", closefd=True) as handle:
            handle.write(rendered)
            handle.flush()
            os.fsync(handle.fileno())
    except BaseException:
        try:
            os.close(fd)
        except OSError:
            pass
        raise
print(rendered, end="")
raise SystemExit(0 if receipt["status"] == "PASS" else 1)
