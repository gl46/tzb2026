#!/usr/bin/env python3
import argparse
import hashlib
from pathlib import Path
parser = argparse.ArgumentParser()
parser.add_argument("--path", required=True)
parser.add_argument("--expected", required=True)
args = parser.parse_args()
path = Path(args.path)
actual = hashlib.sha256(path.read_bytes()).hexdigest()
print(f"FILE_BYTES_SHA256 {path} {actual}")
raise SystemExit(0 if actual == args.expected else 1)
